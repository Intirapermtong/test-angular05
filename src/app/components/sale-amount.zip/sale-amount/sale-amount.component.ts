import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sale-amount',
  templateUrl: './sale-amount.component.html',
  styleUrls: ['./sale-amount.component.css']
})
export class SaleAmountComponent implements OnInit {

  saleAmount: string = '';

  constructor() { }

  ngOnInit(): void {

  }

  isNumberKey(evt: any){
    console.log('saleAmount::: ' );
    console.log(this.saleAmount);
    this.saleAmount = this.formatMoney(this.saleAmount);

  }

  formatMoney(number: any) {
    console.log(number);
    return Number(number).toLocaleString(undefined, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
  }

}
